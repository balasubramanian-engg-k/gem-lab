@extends('layouts.app')

@section('content')
<div class="max-w-7xl mx-auto p-6">
    <div class="bg-white rounded-lg shadow-md p-6">
        <div class="flex justify-between items-center mb-6 flex-wrap gap-2">
            <h1 class="text-2xl font-bold text-gray-800">Making MC</h1>
            <div class="flex items-center gap-2">
                <a href="{{ route('making-mc.export', request()->query()) }}" class="px-4 py-2 bg-green-600 text-white rounded-lg shadow hover:bg-green-700 transition inline-flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    Export to Excel
                </a>
                <a href="{{ route('making-mc.create') }}" class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 transition">Create Labour receipt</a>
            </div>
        </div>
        @if (session('success'))
            <div class="mb-4 p-4 bg-green-100 text-green-700 rounded">{{ session('success') }}</div>
        @endif
        @if (session('error'))
            <div class="mb-4 p-4 bg-red-100 text-red-700 rounded">{{ session('error') }}</div>
        @endif

        <form method="GET" action="{{ route('making-mc.index') }}" class="mb-4 flex flex-wrap gap-4 items-end">
            <div>
                <label for="craftman_name" class="block text-sm font-medium text-gray-700 mb-1">Craftman name</label>
                <input type="text" name="craftman_name" id="craftman_name" value="{{ request('craftman_name') }}" placeholder="Filter by name" class="border border-gray-300 rounded-lg px-4 py-2">
            </div>
            <div>
                <label for="workflow_status" class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select name="workflow_status" id="workflow_status" class="border border-gray-300 rounded-lg px-4 py-2">
                    <option value="">All</option>
                    <option value="ISSUED" {{ request('workflow_status') === 'ISSUED' ? 'selected' : '' }}>Issued</option>
                    <option value="PARTIALLY_RECEIVED" {{ request('workflow_status') === 'PARTIALLY_RECEIVED' ? 'selected' : '' }}>Partially Received</option>
                    <option value="FULLY_RECEIVED" {{ request('workflow_status') === 'FULLY_RECEIVED' ? 'selected' : '' }}>Fully Received</option>
                </select>
            </div>
            <button type="submit" class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700">Filter</button>
        </form>

        <div class="overflow-x-auto">
            <table class="min-w-full border border-gray-200">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700">MC Id</th>
                        <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700">Craftman</th>
                        <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700">Product</th>
                        <th class="px-4 py-2 text-right text-sm font-semibold text-gray-700">Count issued</th>
                        <th class="px-4 py-2 text-right text-sm font-semibold text-gray-700">Silver (g)</th>
                        <th class="px-4 py-2 text-right text-sm font-semibold text-gray-700">Amount</th>
                        <th class="px-4 py-2 text-right text-sm font-semibold text-gray-700">Count received</th>
                        <th class="px-4 py-2 text-right text-sm font-semibold text-gray-700">Weight received</th>
                        <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700">Status</th>
                        <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700">Date</th>
                        <th class="px-4 py-2 text-left text-sm font-semibold text-gray-700">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($receipts as $r)
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-4 py-2 text-sm font-medium text-gray-900">{{ $r->mc_id }}</td>
                        <td class="px-4 py-2 text-sm text-gray-700">{{ $r->craftman_display_name }}</td>
                        <td class="px-4 py-2 text-sm text-gray-700">{{ $r->productType->name ?? '-' }}</td>
                        <td class="px-4 py-2 text-sm text-right">{{ $r->count_issued }}</td>
                        <td class="px-4 py-2 text-sm text-right">{{ number_format($r->silver_gross_weight, 3) }}</td>
                        <td class="px-4 py-2 text-sm text-right">{{ number_format($r->amount, 2) }}</td>
                        <td class="px-4 py-2 text-sm text-right">{{ $r->total_count_received }}</td>
                        <td class="px-4 py-2 text-sm text-right">{{ number_format($r->total_weight_received, 3) }}</td>
                        <td class="px-4 py-2 text-sm">
                            @if($r->workflow_status === 'FULLY_RECEIVED')
                                <span class="px-2 py-0.5 rounded bg-green-100 text-green-800">Fully Received</span>
                            @elseif($r->workflow_status === 'PARTIALLY_RECEIVED')
                                <span class="px-2 py-0.5 rounded bg-amber-100 text-amber-800">Partially Received</span>
                            @else
                                <span class="px-2 py-0.5 rounded bg-gray-100 text-gray-800">Issued</span>
                            @endif
                        </td>
                        <td class="px-4 py-2 text-sm text-gray-700">{{ $r->created_at->format('d-m-Y') }}</td>
                        <td class="px-4 py-2 text-sm">
                            <a href="{{ route('making-mc.show', $r) }}" class="text-indigo-600 hover:underline">View</a>
                            @if($r->workflow_status !== 'FULLY_RECEIVED')
                                | <a href="{{ route('making-mc.returns.create', $r) }}" class="text-green-600 hover:underline">Add return</a>
                            @endif
                            | <a href="{{ route('making-mc.edit', $r) }}" class="text-gray-600 hover:underline">Edit</a>
                            | <a href="{{ route('making-mc.delete', $r) }}" class="text-red-600 hover:underline">Delete</a>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="11" class="px-4 py-8 text-center text-gray-500">No labour receipts yet. Create one to get started.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($receipts->hasPages())
            <div class="mt-4">{{ $receipts->links() }}</div>
        @endif
    </div>
</div>
@endsection
