<?php

namespace App\Observers;

use App\Models\Invoice;
use App\Models\InvoiceChangelog;

class InvoiceObserver
{
    /**
     * Handle the Invoice "created" event.
     */
    public function created(Invoice $invoice): void
    {
        InvoiceChangelog::create([
            'invoice_id' => $invoice->id,
            'user_id' => auth()->id(),
            'action' => 'created',
            'description' => 'Invoice created',
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);
    }

    /**
     * Handle the Invoice "updated" event.
     */
    public function updated(Invoice $invoice): void
    {
        $changes = $invoice->getChanges();
        $original = $invoice->getOriginal();
        
        // Skip if only updated_at changed
        if (count($changes) === 1 && isset($changes['updated_at'])) {
            return;
        }
        
        foreach ($changes as $field => $newValue) {
            // Skip timestamps
            if (in_array($field, ['updated_at', 'created_at'])) {
                continue;
            }
            
            $oldValue = $original[$field] ?? null;
            
            // Format values for display
            $formattedOldValue = $this->formatValue($oldValue, $field);
            $formattedNewValue = $this->formatValue($newValue, $field);
            
            InvoiceChangelog::create([
                'invoice_id' => $invoice->id,
                'user_id' => auth()->id(),
                'action' => $field === 'status' ? 'status_changed' : 'updated',
                'field_name' => $field,
                'old_value' => $formattedOldValue,
                'new_value' => $formattedNewValue,
                'field_label' => $this->getFieldLabel($field),
                'description' => $this->getDescription($field, $formattedOldValue, $formattedNewValue),
                'ip_address' => request()->ip(),
                'user_agent' => request()->userAgent(),
            ]);
        }
    }

    /**
     * Handle the Invoice "deleted" event.
     */
    public function deleted(Invoice $invoice): void
    {
        InvoiceChangelog::create([
            'invoice_id' => $invoice->id,
            'user_id' => auth()->id(),
            'action' => 'deleted',
            'description' => 'Invoice deleted',
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);
    }

    /**
     * Format value based on field type.
     */
    private function formatValue($value, $field)
    {
        if ($value === null) {
            return '-';
        }

        // Format dates
        if (in_array($field, ['delivered_date', 'created_at', 'updated_at']) && $value) {
            try {
                return \Carbon\Carbon::parse($value)->format('d-m-Y');
            } catch (\Exception $e) {
                return $value;
            }
        }

        // Format product type
        if ($field === 'product_type_id' && $value) {
            $productType = \App\Models\ProductType::find($value);
            return $productType ? $productType->name : $value;
        }

        // Format boolean
        if ($field === 'toggle_silver_cost') {
            return $value ? 'Enabled' : 'Disabled';
        }

        // Format numbers
        if (in_array($field, ['total_count', 'actual_silver_weight', 'stone_cost', 'wastage_making_certification_cost'])) {
            return is_numeric($value) ? number_format($value, 2) : $value;
        }

        return $value;
    }

    /**
     * Get human-readable field label.
     */
    private function getFieldLabel($field)
    {
        $labels = [
            'customer_name' => 'Customer Name',
            'location' => 'Location',
            'status' => 'Status',
            'delivered_date' => 'Delivered Date',
            'total_count' => 'Total Count',
            'actual_silver_weight' => 'Actual Silver Weight',
            'remarks' => 'Remarks',
            'assignee_name' => 'Assignee',
            'stone_cost' => 'Stone Cost',
            'wastage_making_certification_cost' => 'Wastage+Making+Certification Cost',
            'product_type_id' => 'Product Type',
            'toggle_silver_cost' => 'Toggle Silver Cost',
        ];

        return $labels[$field] ?? ucfirst(str_replace('_', ' ', $field));
    }

    /**
     * Generate description for the change.
     */
    private function getDescription($field, $oldValue, $newValue)
    {
        $label = $this->getFieldLabel($field);
        
        if ($field === 'status') {
            return "Status changed from '{$oldValue}' to '{$newValue}'";
        }
        
        return "{$label} changed from '{$oldValue}' to '{$newValue}'";
    }
}
